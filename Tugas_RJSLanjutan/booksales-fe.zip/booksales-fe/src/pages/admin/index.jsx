export default function dashboard() {
    return(
        <>
        <h1>Dashboard</h1>
        </>
    )
}